﻿<?php
session_start();
if(isset($_SESSION['reset']))
{
	
} else
  header("location: Forgot Password.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<!--favicon-->
        <link rel="shortcut icon" href="favicon.ico" type="image/icon">
        <link rel="icon" href="favicon.ico" type="image/icon">
      <!-- Footer -->
        <link type="text/css" rel="stylesheet" href="css/style.css">
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">  
	    <title>HOD-Reset Password</title>
        <meta name="description" content="">
        <meta name="author" content="templatemo">
	    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
	    <link href="css/font-awesome.min.css" rel="stylesheet">
	    <link href="css/bootstrap.min.css" rel="stylesheet">
	    <link href="css/templatemo-style.css" rel="stylesheet">
        <!-- Footer -->
        <link type="text/css" rel="stylesheet" href="../../Homepage/css/style.css">
	    
	    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	    <!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	    <![endif]-->
	</head>
	<body class="light-gray-bg">
		<div class="templatemo-content-widget templatemo-login-widget white-bg">
			<header class="text-center">
	          <div class="square"></div>
	          <h1>Reset Password</h1>
	        </header>
	        <form action="rs1.php" class="templatemo-login-form" method="POST" enctype="multipart/form-data">
				<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>	        		
		              	<input type="text" name="USN" class="form-control" placeholder="Username" >           
		          	</div>	
	        	</div>
	        	<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>	        		
		              	<input type="password" name="PASSWORD" class="form-control" placeholder="New Password" >           
		          	</div>	
	        	</div>
				<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>	        		
		              	<input type="password" name="repassword" class="form-control" placeholder="Retype Password" >           
		          	</div>	
				</div>
				<div class="form-group">
					<button type="submit" class="templatemo-blue-button width-100">Reset Password</button>
				</div>
	        </form>
		</div>
		
			<!--Footer-->
		       <div class="footer">
			<div class="container">
				<div class="col-md-4 ftr_navi ftr">
					<h3>NAVIGATION</h3>
					<ul>
						<li>
							<a href="../Homepage/index.php">Home</a>
						</li>
						<li>
							<a href="../Profilers/SProfile/index.php">Student Login</a>
						</li>
						<li>
							<a href="../Profilers/PProfile/index.php">Placement Login</a>
						</li>
						<li>
							<a href="../Profilers/HODProfile/index.php">HOD Login</a>
						</li>
						<li>
							<a href="../Profilers/Priprofile/index.php">Administrative Login</a>
						</li>
					</ul>
				</div>
				<div class="col-md-4 ftr_navi ftr">
					<h3>MEMBERS</h3>
					<ul>
						<li>
							<a href="#">Customer Support</a>
						</li>
						<li>
							<a href="#">Placement Support</a>
						</li>
						<li>
							<a href="#">Faculty Support</a>
						</li>
						<li>
							<a href="#">Registered Companies</a>
						</li>
						<li>
							<a href="#">Training</a>
						</li>
					</ul>
				</div>
				<div class="col-md-4 get_in_touch ftr">
				<h3>GET IN TOUCH</h3>
					<p>Nehru Nagar,Shivabasava Nagar </p>
					<p>Belagavi , Karnataka 590010</p>
					<p>(0831)2407172</p>
					<a href="mailto:info@sgbit.edu.in">info@sgbit.edu.in</a>
				</div>
				
				<div class="clearfix"></div>
			</div>
		</div>
	</body>
</html>